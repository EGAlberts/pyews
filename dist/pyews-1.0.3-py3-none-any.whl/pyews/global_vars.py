settings = {
    "Initialized": False,
    "IP" : None,
    "main_component_path": None, #path to the main component
    "proxy_JSON": None
}